#pragma once
#include <Arduino.h>
#include <stdarg.h>

// mylog.h 未随仓库提供，这里按原固件的串口日志行为补一个最小实现：
// 所有级别都直接打印到 Serial（实机日志里 LOG_DEBUG 级别的信息是会出现的）。
#ifndef LOG_DEBUG
#define LOG_DEBUG false
#endif
#ifndef LOG_INFO
#define LOG_INFO true
#endif
#ifndef LOG_ERROR
#define LOG_ERROR true
#endif

class MyLog {
  public:
    static MyLog& logger() {
      static MyLog inst;
      return inst;
    }

    template <typename T>
    void println(int level, const T& value) {
      (void)level;
      Serial.println(value);
    }

    void println(int level) {
      (void)level;
      Serial.println();
    }

    void printf(int level, const char* fmt, ...) {
      (void)level;
      char buf[256];
      va_list ap;
      va_start(ap, fmt);
      vsnprintf(buf, sizeof(buf), fmt, ap);
      va_end(ap);
      Serial.print(buf);
    }
};
